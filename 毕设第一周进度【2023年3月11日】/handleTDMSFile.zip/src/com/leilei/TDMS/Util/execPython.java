package com.leilei.TDMS.Util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * java调用python处理TDMS文件的脚本
 * */
public class execPython {

    //Python解释器路径
    private static String pythonExePath = "D:\\DevelopTools\\Anaconda\\python.exe";

    //Python脚本路径
    private static String pythonFilePath = "src\\com\\leilei\\TDMS\\Resource\\handleTDMS.py";

    //执行python脚本
    public static TDMS getDataFromTDMS(String filePath) {
        //存储TDMS数据
        TDMS tdms = new TDMS();
        BufferedReader br = null;
        try{
            //参数列表
            String[] args1 = new String[] {execPython.pythonExePath,execPython.pythonFilePath,filePath};
            //执行python脚本
            Process proc = Runtime.getRuntime().exec(args1);
            //缓冲字符流
            br = new BufferedReader(new InputStreamReader(proc.getInputStream(),"GBK"));
            String line = null;
            String channelName = "";
            ArrayList<Double> dataList = new ArrayList();
            Boolean firstFlag = true;
            while((line = br.readLine())!=null) {
                //识别group名称
                if(line.indexOf("*") >= 0) {
                    tdms.setGroupName(line.replace("*","").trim());
                }
                //识别channel名称
                else if(line.indexOf("#") >= 0) {
                    if(!firstFlag) {
                        tdms.addChannel(channelName,dataList);
                    }else {
                        firstFlag = false;
                    }
                    channelName = line.replace("#","").trim();
                    dataList = new ArrayList<Double>();
                }
                //识别channel数据
                else {
                    line = line.replace("[","").replace("]","").trim();
                    String[] str = line.split(" ");
                    for(String temp : str) {
                        if(!(" ".equals(temp)) && !("".equals(temp))) {
                            dataList.add(Double.valueOf(temp));
                        }
                    }
                }
            }
            //插入最后一组数据
            tdms.addChannel(channelName,dataList);
            proc.waitFor();
        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(null != br) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return tdms;
    }


    public static void main(String[] args) {

        //TDMS文件数据 处理成 TDMS类结构形式
        TDMS tdms = execPython.getDataFromTDMS("src/com/leilei/TDMS/Resource/tdmsFile/EX1000A.tdms");
        tdms.show();
    }
}
