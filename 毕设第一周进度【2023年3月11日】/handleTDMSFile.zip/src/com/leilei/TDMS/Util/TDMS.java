package com.leilei.TDMS.Util;

import java.util.*;

//TDMS数据结构
public class TDMS {

    //存储TDMS数据
    //channel_name channel_dataList
    private Map<String, ArrayList> TDMSMap = new LinkedHashMap<>();

    //存储Group_name
    private String groupName;

    //插入Channel数据
    public void addChannel(String channelName,ArrayList dataList) {
        TDMSMap.put(channelName,dataList);
    }

    //输出TDMS数据
    public void show() {
        System.out.println("Group Name -> " + this.groupName);
        Set<Map.Entry<String, ArrayList>> entries = TDMSMap.entrySet();
        for (Map.Entry<String, ArrayList> item : entries) {
            System.out.println(item);
        }
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }
}
