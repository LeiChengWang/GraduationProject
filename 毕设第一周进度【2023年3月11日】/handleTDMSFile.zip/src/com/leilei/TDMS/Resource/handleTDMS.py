from nptdms import TdmsFile
import numpy as np
import sys

# 控制numpy输出不省略
np.set_printoptions(threshold=np.inf)
# 读取命令行传入的第一个参数：TDMS文件路径
filePath = sys.argv[1]
# 解析TDMS文件
with TdmsFile.open(filePath) as tdms_file:
    # 可以按组名索引来访问TDMS文件中的组，使用groups()方法直接访问所有组
    for group in tdms_file.groups():
        group_name = group.name
        print("*",group_name,"*")
        # 可以通过通道名称来索引来访问这个组中的一个通道，使用 channels()方法直接访问所有通道
        for channel in group.channels():
            channel_name = channel.name
            print("#",channel_name,"#")
            # 根据索引读取通道
            channel = tdms_file[group_name][channel_name]
            # 将此通道中所有的数据作为numpy数组获取
            all_channel_data = channel[:]
            num = np.array(all_channel_data)
            print(num)